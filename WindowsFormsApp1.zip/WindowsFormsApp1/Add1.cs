﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Add1 : Form
    {
        public Add1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    One main = this.Owner as One;
                    if (main != null)
                    {

                        string dbPath = Path.Combine(Application.StartupPath, "CulinaryDatabase.accdb");
                        string connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";

                        using (OleDbConnection connection = new OleDbConnection(connectionString))
                        {
                            connection.Open();

                            OleDbCommand command = new OleDbCommand("INSERT INTO INSERT INTO [tblDishes] ([DishName], [DishCategory], [Recipe], [PortionWeightGrams], [PortionsPerRecipe]) VALUES (?, ?, ?, ?, ?)", connection);
                            command.Parameters.AddWithValue("@DishName", textBox1.Text);
                            command.Parameters.AddWithValue("@DishCategory", textBox2.Text);
                            command.Parameters.AddWithValue("@Recipe", textBox3.Text);
                            command.Parameters.AddWithValue("@PortionWeightGrams", textBox4.Text);
                            command.Parameters.AddWithValue("@PortionsPerRecipe", textBox5.Text);
                            command.ExecuteNonQuery();
                        }

                        DataRow nRow = main.culinaryDatabaseDataSet.Tables[0].NewRow();
                        nRow[1] = textBox1.Text;
                        nRow[2] = textBox2.Text;
                        nRow[3] = textBox3.Text;
                        nRow[4] = textBox4.Text;
                        nRow[5] = textBox5.Text;

                        main.culinaryDatabaseDataSet.Tables[0].Rows.Add(nRow);
                        main.culinaryDatabaseDataSet.Tables[0].AcceptChanges();
                        main.dataGridView1.Refresh();

                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
