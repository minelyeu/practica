﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Add3 : Form
    {
        public Add3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    One main = this.Owner as One;
                    if (main != null)
                    {

                        string dbPath = Path.Combine(Application.StartupPath, "CulinaryDatabase.accdb");
                        string connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";

                        using (OleDbConnection connection = new OleDbConnection(connectionString))
                        {
                            connection.Open();

                            OleDbCommand command = new OleDbCommand("INSERT INTO INSERT INTO [tblProducts] ([ProductName], [ProductCategory], [CaloriesPer100Units], [PricePerUnit], [UnitOfMeasure]) VALUES (?, ?, ?, ?, ?)", connection);
                            command.Parameters.AddWithValue("@ProductName", textBox1.Text);
                            command.Parameters.AddWithValue("@ProductCategory", textBox2.Text);
                            command.Parameters.AddWithValue("@CaloriesPer100Units", textBox3.Text);
                            command.Parameters.AddWithValue("@PricePerUnit", textBox4.Text);
                            command.Parameters.AddWithValue("@UnitOfMeasure", textBox5.Text);
                            command.ExecuteNonQuery();
                        }

                        DataRow nRow = main.culinaryDatabaseDataSet.Tables[0].NewRow();
                        nRow[1] = textBox1.Text;
                        nRow[2] = textBox2.Text;
                        nRow[3] = textBox3.Text;
                        nRow[4] = textBox4.Text;
                        nRow[5] = textBox5.Text;

                        main.culinaryDatabaseDataSet.Tables[0].Rows.Add(nRow);
                        main.culinaryDatabaseDataSet.Tables[0].AcceptChanges();
                        main.dataGridView1.Refresh();

                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}");
                }
            }
        }
    }
}
