using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AddRecipeForm : Form
    {
        public AddRecipeForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Валидация полей
            if (string.IsNullOrWhiteSpace(textBoxDishName.Text))
            {
                MessageBox.Show("Пожалуйста, введите название блюда.");
                return;
            }
            if (string.IsNullOrWhiteSpace(comboBoxCategory.Text))
            {
                MessageBox.Show("Пожалуйста, выберите категорию.");
                return;
            }
            if (string.IsNullOrWhiteSpace(textBoxRecipe.Text))
            {
                MessageBox.Show("Пожалуйста, введите рецепт.");
                return;
            }

            try
            {
                string dbPath = Path.Combine(Application.StartupPath, "CulinaryDatabase.accdb");
                string connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();

                    // Проверка на существующее блюдо
                    string checkQuery = "SELECT COUNT(*) FROM [tblDishes] WHERE [DishName] = ? AND [DishCategory] = ?";
                    using (OleDbCommand checkCommand = new OleDbCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@DishName", textBoxDishName.Text);
                        checkCommand.Parameters.AddWithValue("@DishCategory", comboBoxCategory.Text);
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Блюдо с таким названием уже существует в этой категории.");
                            return;
                        }
                    }

                    // Вставка нового рецепта
                    string insertQuery = "INSERT INTO [tblDishes] ([DishName], [DishCategory], [Recipe], [PortionWeightGrams], [PortionsPerRecipe]) VALUES (?, ?, ?, ?, ?)";
                    using (OleDbCommand insertCommand = new OleDbCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@DishName", textBoxDishName.Text);
                        insertCommand.Parameters.AddWithValue("@DishCategory", comboBoxCategory.Text);
                        insertCommand.Parameters.AddWithValue("@Recipe", textBoxRecipe.Text);
                        
                        int portionWeight = 0;
                        int portions = 0;
                        int.TryParse(textBoxPortionWeight.Text, out portionWeight);
                        int.TryParse(textBoxPortions.Text, out portions);
                        
                        insertCommand.Parameters.AddWithValue("@PortionWeightGrams", portionWeight);
                        insertCommand.Parameters.AddWithValue("@PortionsPerRecipe", portions);
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Рецепт успешно добавлен!");
                
                // Очистка полей
                textBoxDishName.Text = "";
                comboBoxCategory.Text = "";
                textBoxRecipe.Text = "";
                textBoxPortionWeight.Text = "";
                textBoxPortions.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении рецепта: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(105)))), ((int)(((byte)(40)))));
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(158)))), ((int)(((byte)(158)))));
        }
    }
}

