﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetupRecipeCards();
        }

        private void SetupRecipeCards()
        {
            // Добавляем эффекты наведения на карточки рецептов
            AddHoverEffect(groupBox1);
            AddHoverEffect(groupBox2);
            AddHoverEffect(groupBox3);
            AddHoverEffect(groupBox5);
        }

        private void AddHoverEffect(GroupBox groupBox)
        {
            groupBox.MouseEnter += (s, e) =>
            {
                groupBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
                groupBox.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            };
            groupBox.MouseLeave += (s, e) =>
            {
                groupBox.BackColor = System.Drawing.Color.White;
                groupBox.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LogOut af = new LogOut();
            af.Owner = this;
            af.Show();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(140)))), ((int)(((byte)(20)))));
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
        }
    }
}
