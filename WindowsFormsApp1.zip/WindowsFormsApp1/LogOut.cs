﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LogOut : Form
    {
        private const string ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=CulinaryDatabase.accdb;";
        public LogOut()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Register af = new Register();
            af.Owner = this;
            af.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string loginuser = textBox1.Text;
            string password = textBox2.Text;

            DataTable table = new DataTable();

            using (OleDbConnection connection = new OleDbConnection(ConnectionString))
            {
                string query = "SELECT * FROM [tblUsers] WHERE [Username] = @ul AND [Password] = @up";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ul", loginuser);
                    command.Parameters.AddWithValue("@up", password);

                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    adapter.Fill(table);
                }
            }

            if (table.Rows.Count > 0)
            {
                // Безопасное получение Role с проверкой на null
                object roleValue = table.Rows[0]["Role"];
                string userRole = (roleValue == DBNull.Value || roleValue == null) 
                    ? "User" 
                    : roleValue.ToString().Trim();

                if (string.IsNullOrEmpty(userRole))
                {
                    userRole = "User";
                }

                bool isAdmin = string.Equals(userRole, "admin", StringComparison.OrdinalIgnoreCase);

                UserForm nextForm = new UserForm(isAdmin);
                nextForm.Owner = this;
                nextForm.Show();
                this.Hide();

                MessageBox.Show("Добро Пожаловать.");
            }
            else
            {
                MessageBox.Show("Ошибка при вводе данных аккаунта.");
            }
        }
    }
}