﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class One : Form
    {
        public One()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void One_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "culinaryDatabaseDataSet4.tblUsers". При необходимости она может быть перемещена или удалена.
            this.tblUsersTableAdapter1.Fill(this.culinaryDatabaseDataSet4.tblUsers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "culinaryDatabaseDataSet2.tblProducts". При необходимости она может быть перемещена или удалена.
            this.tblProductsTableAdapter.Fill(this.culinaryDatabaseDataSet2.tblProducts);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "culinaryDatabaseDataSet1.tblDishes". При необходимости она может быть перемещена или удалена.
            this.tblDishesTableAdapter.Fill(this.culinaryDatabaseDataSet1.tblDishes);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "culinaryDatabaseDataSet.tblDishComposition". При необходимости она может быть перемещена или удалена.
            this.tblDishCompositionTableAdapter.Fill(this.culinaryDatabaseDataSet.tblDishComposition);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tblDishCompositionTableAdapter.Update(culinaryDatabaseDataSet);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tblDishesTableAdapter.Update(culinaryDatabaseDataSet1);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            tblProductsTableAdapter.Update(culinaryDatabaseDataSet2);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            tblUsersTableAdapter.Update(culinaryDatabaseDataSet3);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Add4 af = new Add4();
            af.Owner = this;
            af.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Add2 af = new Add2();
            af.Owner = this;
            af.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Seach2 af = new Seach2();
            af.Owner = this;
            af.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Seach1 af = new Seach1();
            af.Owner = this;
            af.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Add3 af = new Add3();
            af.Owner = this;
            af.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Seach3 af = new Seach3();
            af.Owner = this;
            af.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Seach4 af = new Seach4();
            af.Owner = this;
            af.Show();
        }
    }
}
