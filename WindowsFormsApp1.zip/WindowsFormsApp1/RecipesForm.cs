using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class RecipesForm : Form
    {
        private readonly string category;
        private readonly bool canEditRecipes;
        private DataTable recipesTable;

        public RecipesForm(string categoryName, bool canEditRecipes = false)
        {
            InitializeComponent();
            this.category = categoryName;
            this.canEditRecipes = canEditRecipes;
            this.Text = $"Рецепты - {categoryName}";
            if (label1 != null)
            {
                label1.Text = $"Рецепты: {categoryName}";
            }
        }

        private void RecipesForm_Load(object sender, EventArgs e)
        {
            LoadRecipes();
        }

        private void LoadRecipes()
        {
            try
            {
                if (dataGridView1 == null)
                {
                    MessageBox.Show("Ошибка: DataGridView не инициализирован.");
                    return;
                }

                // Используем тот же подход, что и в других формах
                string dbPath = Path.Combine(Application.StartupPath, "CulinaryDatabase.accdb");
                string connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";

                recipesTable = new DataTable();
                
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT DishID, DishName, Recipe, PortionWeightGrams, PortionsPerRecipe FROM [tblDishes] WHERE [DishCategory] = ?";
                    using (OleDbCommand command = new OleDbCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Category", category);
                        OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                        adapter.Fill(recipesTable);
                    }
                }

                // Устанавливаем источник данных
                dataGridView1.DataSource = recipesTable;
                dataGridView1.ReadOnly = !canEditRecipes;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.AllowUserToDeleteRows = false;
                buttonSaveChanges.Visible = canEditRecipes;
                if (!canEditRecipes)
                {
                    dataGridView1.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(100)))));
                    dataGridView1.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
                }

                // Настройка отображения - проверяем наличие колонок
                if (dataGridView1.Columns != null && dataGridView1.Columns.Count > 0)
                {
                    // Стиль заголовков
                    System.Windows.Forms.DataGridViewCellStyle headerStyle = new System.Windows.Forms.DataGridViewCellStyle();
                    headerStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
                    headerStyle.ForeColor = System.Drawing.Color.White;
                    headerStyle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
                    headerStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
                    headerStyle.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
                    dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;
                    dataGridView1.ColumnHeadersHeight = 40;

                    // Стиль ячеек
                    System.Windows.Forms.DataGridViewCellStyle cellStyle = new System.Windows.Forms.DataGridViewCellStyle();
                    cellStyle.BackColor = System.Drawing.Color.White;
                    cellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
                    cellStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
                    cellStyle.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
                    dataGridView1.DefaultCellStyle = cellStyle;

                    // Альтернативный цвет строк
                    dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
                    
                    // Выделение строки
                    dataGridView1.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(100)))));
                    dataGridView1.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;

                    if (dataGridView1.Columns.Contains("DishID"))
                    {
                        dataGridView1.Columns["DishID"].Visible = false;
                        dataGridView1.Columns["DishID"].ReadOnly = true;
                    }
                    if (dataGridView1.Columns.Contains("DishName"))
                    {
                        dataGridView1.Columns["DishName"].HeaderText = "Название блюда";
                        dataGridView1.Columns["DishName"].Width = 200;
                    }
                    if (dataGridView1.Columns.Contains("Recipe"))
                    {
                        dataGridView1.Columns["Recipe"].HeaderText = "Рецепт";
                        dataGridView1.Columns["Recipe"].Width = 450;
                        dataGridView1.Columns["Recipe"].DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
                    }
                    if (dataGridView1.Columns.Contains("PortionWeightGrams"))
                    {
                        dataGridView1.Columns["PortionWeightGrams"].HeaderText = "Вес порции (г)";
                        dataGridView1.Columns["PortionWeightGrams"].Width = 120;
                    }
                    if (dataGridView1.Columns.Contains("PortionsPerRecipe"))
                    {
                        dataGridView1.Columns["PortionsPerRecipe"].HeaderText = "Порций";
                        dataGridView1.Columns["PortionsPerRecipe"].Width = 80;
                    }
                    
                    // Настройка для отображения длинного текста
                    dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Ошибка базы данных при загрузке рецептов: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке рецептов: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(110)))), ((int)(((byte)(160)))));
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(130)))), ((int)(((byte)(180)))));
        }

        private void buttonSaveChanges_Click(object sender, EventArgs e)
        {
            if (!canEditRecipes)
            {
                MessageBox.Show("Недостаточно прав для сохранения изменений.");
                return;
            }

            dataGridView1.EndEdit();

            if (recipesTable == null)
            {
                MessageBox.Show("Нет данных для сохранения.");
                return;
            }

            DataTable changes = recipesTable.GetChanges(DataRowState.Modified);
            if (changes == null || changes.Rows.Count == 0)
            {
                MessageBox.Show("Изменения отсутствуют.");
                return;
            }

            try
            {
                string dbPath = Path.Combine(Application.StartupPath, "CulinaryDatabase.accdb");
                string connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    foreach (DataRow row in changes.Rows)
                    {
                        if (row["DishID"] == DBNull.Value)
                        {
                            continue;
                        }

                        string updateQuery = "UPDATE [tblDishes] SET [DishName] = ?, [Recipe] = ?, [PortionWeightGrams] = ?, [PortionsPerRecipe] = ? WHERE [DishID] = ?";
                        using (OleDbCommand updateCommand = new OleDbCommand(updateQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@DishName", row["DishName"] ?? string.Empty);
                            updateCommand.Parameters.AddWithValue("@Recipe", row["Recipe"] ?? string.Empty);

                            int portionWeight = 0;
                            int.TryParse(row["PortionWeightGrams"]?.ToString(), out portionWeight);
                            updateCommand.Parameters.AddWithValue("@PortionWeightGrams", portionWeight);

                            int portions = 0;
                            int.TryParse(row["PortionsPerRecipe"]?.ToString(), out portions);
                            updateCommand.Parameters.AddWithValue("@PortionsPerRecipe", portions);

                            updateCommand.Parameters.AddWithValue("@DishID", row["DishID"]);
                            updateCommand.ExecuteNonQuery();
                        }
                    }
                }

                recipesTable.AcceptChanges();
                MessageBox.Show("Изменения успешно сохранены.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении изменений: " + ex.Message);
            }
        }
    }
}

