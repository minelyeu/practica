﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void Register_Load(object sender, EventArgs e)
        {
            // Загружаем данные из базы перед регистрацией
            this.tblUsersTableAdapter.Fill(this.culinaryDatabaseDataSet3.tblUsers);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Проверка на пустые поля
            if (string.IsNullOrWhiteSpace(tbUserName.Text))
            {
                MessageBox.Show("Пожалуйста, введите логин.");
                return;
            }
            if (string.IsNullOrWhiteSpace(tbPassword.Text))
            {
                MessageBox.Show("Пожалуйста, введите пароль.");
                return;
            }
            if (tbPassword.Text != tbReloadPas.Text)
            {
                MessageBox.Show("Пароли не совпадают. Пожалуйста, попробуйте снова.");
                return;
            }
            if (!IsValidPassword(tbPassword.Text))
            {
                MessageBox.Show("Пароль содержит недопустимые символы. Пожалуйста, используйте только буквы и цифры.");
                return;
            }

            try
            {
                // Используем прямой SQL запрос для вставки, чтобы установить Role
                string dbPath = Path.Combine(Application.StartupPath, "CulinaryDatabase.accdb");
                string connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};Persist Security Info=False;";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();

                    // Проверяем, существует ли пользователь
                    string checkQuery = "SELECT COUNT(*) FROM [tblUsers] WHERE [Username] = ?";
                    using (OleDbCommand checkCommand = new OleDbCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Username", tbUserName.Text);
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Пользователь с таким логином уже существует.");
                            return;
                        }
                    }

                    // Вставляем нового пользователя с Role = "User" по умолчанию
                    string insertQuery = "INSERT INTO [tblUsers] ([Username], [Password], [Role]) VALUES (?, ?, ?)";
                    using (OleDbCommand insertCommand = new OleDbCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@Username", tbUserName.Text);
                        insertCommand.Parameters.AddWithValue("@Password", tbPassword.Text);
                        insertCommand.Parameters.AddWithValue("@Role", "User");
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Регистрация успешно завершена! Теперь вы можете войти.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при регистрации: " + ex.Message);
            }
        }
        private bool IsValidPassword(string password)
        {
            foreach (char c in password)
            {
                if (!char.IsLetterOrDigit(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void tbPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}