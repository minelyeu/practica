﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class UserForm : Form
    {
        private readonly bool canManageRecipes;

        public UserForm(bool canManageRecipes = false)
        {
            this.canManageRecipes = canManageRecipes;
            InitializeComponent();
            ApplyRolePermissions();
        }

        private void ApplyRolePermissions()
        {
            buttonAddRecipe.Visible = canManageRecipes;
            buttonAddRecipe.Enabled = canManageRecipes;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Русская Кухня
            RecipesForm recipesForm = new RecipesForm("Русская Кухня", canManageRecipes);
            recipesForm.Owner = this;
            recipesForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Кавказская Кухня
            RecipesForm recipesForm = new RecipesForm("Кавказская Кухня", canManageRecipes);
            recipesForm.Owner = this;
            recipesForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Азиатская Кухня
            RecipesForm recipesForm = new RecipesForm("Азиатская Кухня", canManageRecipes);
            recipesForm.Owner = this;
            recipesForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Итальянская Кухня
            RecipesForm recipesForm = new RecipesForm("Итальянская Кухня", canManageRecipes);
            recipesForm.Owner = this;
            recipesForm.Show();
        }

        private void buttonAddRecipe_Click(object sender, EventArgs e)
        {
            if (!canManageRecipes)
            {
                MessageBox.Show("У вас нет прав для добавления рецептов.");
                return;
            }

            AddRecipeForm addRecipeForm = new AddRecipeForm();
            addRecipeForm.Owner = this;
            addRecipeForm.Show();
        }

        private void buttonCategory_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(110)))), ((int)(((byte)(160)))));
            }
        }

        private void buttonCategory_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(130)))), ((int)(((byte)(180)))));
            }
        }

        private void buttonAddRecipe_MouseEnter(object sender, EventArgs e)
        {
            buttonAddRecipe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(105)))), ((int)(((byte)(40)))));
        }

        private void buttonAddRecipe_MouseLeave(object sender, EventArgs e)
        {
            buttonAddRecipe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
        }
    }
}
